package com.example.tema3chiru;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

import Models.User;

public class UsersDisplayAdapter extends RecyclerView.Adapter<UsersDisplayAdapter.ViewHolder> {
    private List<User> myData;
    private Context myContext;

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView;
        RelativeLayout parentLayout;

        public ViewHolder(View view) {
            super(view);

            textView = view.findViewById(R.id.layout_user);
            parentLayout = view.findViewById(R.id.parent_layout);

        }
    }

    public UsersDisplayAdapter(Context mContext, List<User> mData) {
        myContext = mContext;
        myData = mData;
    }

    @Override
    public UsersDisplayAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_user, parent, false);

        final ViewHolder holder = new ViewHolder(view);

        view.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                final int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    User user = myData.get(position);
                    startToDosActivity(user.id);
                }
            }
        });


        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.textView.setText(myData.get(position).id + " " + myData.get(position).name + " " + myData.get(position).username + " " +  myData.get(position).email);
    }

    @Override
    public int getItemCount() {
        return myData.size();
    }

    private void startToDosActivity(Integer id){
        Intent i = new Intent(myContext, ToDosActivity.class);
        i.putExtra("id", id);
        myContext.startActivity(i);
    }


}
