package com.example.tema3chiru;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import Models.User;
import MySingleton.MySingleton;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private String JSON_URL = "https://my-json-server.typicode.com/MoldovanG/JsonServer/users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        getUsers();
    }

    private void getUsers(){
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(JSON_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                List<User> userList = new ArrayList<>();
                for (int i = 0; i < response.length(); i++) {
                    try {
                        User user = new User();
                        JSONObject userJSON = response.getJSONObject(i);
                        user.id = userJSON.getInt("id");
                        user.name = userJSON.getString("name");
                        user.username = userJSON.getString("username");
                        user.email = userJSON.getString("email");
                        userList.add(user);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                UserRecyclerView(userList);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Eroare la conectare VOLLEY" + error.getMessage());
            }
        });

        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(jsonArrayRequest);
    }

    private void UserRecyclerView(List<User> users){
        UsersDisplayAdapter adapter = new UsersDisplayAdapter(this, users);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


}
