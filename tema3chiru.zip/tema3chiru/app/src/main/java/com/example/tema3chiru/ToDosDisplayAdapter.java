package com.example.tema3chiru;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

import Models.ToDo;

public class ToDosDisplayAdapter extends RecyclerView.Adapter<ToDosDisplayAdapter.ViewHolder> {
    private List<ToDo> myData;
    private Context myContext;

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView;
        RelativeLayout parentLayout;

        public ViewHolder(View view) {
            super(view);

            textView = view.findViewById(R.id.to_do);
            parentLayout = view.findViewById(R.id.parent_layout);

        }
    }

    public ToDosDisplayAdapter(Context mContext, List<ToDo> mData) {
        myContext = mContext;
        myData = mData;
    }

    @Override
    public ToDosDisplayAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.to_do, parent, false);

        final ViewHolder holder = new ViewHolder(view);

        view.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                final int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    ToDo toDo = myData.get(position);
                    ToDosActivity toDosActivity = (ToDosActivity)myContext;
                    toDosActivity.setCurrentTitle(toDo.title);
                    toDosActivity.showFragment();
                }
            }
        });


        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.textView.setText(myData.get(position).id + " " + myData.get(position).userId + " " + myData.get(position).title);
    }

    @Override
    public int getItemCount() {
        return myData.size();
    }

}
