package com.example.tema3chiru;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;


public class PickersFragment extends Fragment {

    private Integer currentHour = null;
    private Integer currentMinute = null;
    private Integer currentYear = null;
    private Integer currentMonth = null;
    private Integer currentDay = null;


    private String currentToDoTitle = null;

    public PickersFragment(String newTitle) {
        currentToDoTitle = newTitle;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pickers, container, false);



        final TextView timeView = view.findViewById(R.id.timeTextView);
        final TextView dateView = view.findViewById(R.id.dateTextView);
        final Button btnTimePicker = view.findViewById(R.id.timeButton);
        final Button btnDatePicker = view.findViewById(R.id.dateButton);
        final TextView to_do = view.findViewById(R.id.viewToDo);

        to_do.setText(this.currentToDoTitle);

        btnTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        currentHour = hourOfDay;
                        currentMinute = minutes;
                        timeView.setText(hourOfDay + ":" + minutes);
                    }
                }, 0, 0, true);

                timePickerDialog.show();
            }
        });

        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                currentYear = year;
                                currentMonth = monthOfYear;
                                currentDay = dayOfMonth;
                                dateView.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, 2020, 0, 0);
                datePickerDialog.show();
            }
        });

        return view;
    }



}
