package Models;

public class ToDo {
    public Integer userId;
    public Integer id;
    public String title;
}
